# devopslab1.2
this repo is for the devops lab 1 
